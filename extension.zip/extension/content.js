(() => {
  const TOAST_ID = "gatekeeper-toast";
  const STYLE_ID = "gatekeeper-toast-style";

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${TOAST_ID} {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 2147483647;
        width: min(360px, calc(100vw - 32px));
        background: #0b1220;
        color: #ffffff;
        border-radius: 14px;
        box-shadow: 0 18px 45px rgba(0,0,0,0.35);
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        overflow: hidden;
        user-select: none;
      }
      #${TOAST_ID} .gk-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        background: rgba(255,255,255,0.04);
      }
      #${TOAST_ID} .gk-dot {
        width: 10px;
        height: 10px;
        border-radius: 999px;
        flex: 0 0 auto;
      }
      #${TOAST_ID} .gk-title {
        font-weight: 800;
        font-size: 13px;
        letter-spacing: 0.2px;
      }
      #${TOAST_ID} .gk-sub {
        margin-left: auto;
        opacity: 0.8;
        font-size: 12px;
      }
      #${TOAST_ID} .gk-body { padding: 10px 12px 12px 12px; }
      #${TOAST_ID} .gk-verdict {
        font-weight: 750;
        font-size: 13px;
        margin-bottom: 6px;
      }
      #${TOAST_ID} .gk-url {
        font-size: 12px;
        line-height: 1.35;
        opacity: 0.9;
        word-break: break-word;
      }
      #${TOAST_ID} .gk-actions {
        display: flex;
        gap: 10px;
        padding: 0 12px 12px 12px;
      }
      #${TOAST_ID} .gk-btn {
        all: unset;
        cursor: pointer;
        padding: 7px 10px;
        border-radius: 10px;
        font-size: 12px;
        font-weight: 700;
        border: 1px solid rgba(255,255,255,0.12);
      }
      #${TOAST_ID} .gk-btn-primary {
        background: #2563eb;
        border-color: rgba(37,99,235,0.6);
      }
      #${TOAST_ID} .gk-btn-ghost {
        background: rgba(255,255,255,0.06);
      }
      #${TOAST_ID} .gk-btn:hover { filter: brightness(1.08); }
    `;
    document.documentElement.appendChild(style);
  }

  function removeToast() {
    const el = document.getElementById(TOAST_ID);
    if (el) el.remove();
  }

  function escapeHtml(value) {
    const s = String(value ?? "");
    return s
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function openNewTab(url) {
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function showToast(payload) {
    ensureStyles();
    removeToast();

    const url = String(payload?.url ?? "");
    const verdict = String(payload?.verdict ?? "Risk check");
    const score = payload?.score ?? null;
    const color = String(payload?.color ?? "green").toLowerCase();
    const reportUrl = String(payload?.reportUrl ?? "");

    const isRed = color === "red";
    const dotColor = isRed ? "#ef4444" : "#10b981";
    const verdictColor = isRed ? "#fca5a5" : "#6ee7b7";

    const toast = document.createElement("div");
    toast.id = TOAST_ID;

    toast.innerHTML = `
      <div class="gk-header" style="border-left: 6px solid ${dotColor};">
        <div class="gk-dot" style="background:${dotColor};"></div>
        <div class="gk-title">Gatekeeper</div>
        <div class="gk-sub">Risk score</div>
      </div>

      <div class="gk-body">
        <div class="gk-verdict" style="color:${verdictColor};">
          ${escapeHtml(verdict)}${score === null ? "" : ` (score: ${escapeHtml(score)}/10)`}
        </div>
        <div class="gk-url">${escapeHtml(url)}</div>
      </div>

      <div class="gk-actions">
        <button class="gk-btn gk-btn-primary" id="gk-open">Open report</button>
        <button class="gk-btn gk-btn-ghost" id="gk-dismiss">Dismiss</button>
      </div>
    `;

    toast.querySelector("#gk-open").addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (reportUrl) openNewTab(reportUrl);
      removeToast();
    });

    toast.querySelector("#gk-dismiss").addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      removeToast();
    });

    (document.body || document.documentElement).appendChild(toast);
    setTimeout(removeToast, 8000);
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "GATEKEEPER_PING") {
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "GATEKEEPER_SHOW_TOAST") {
      showToast(message.payload);
      sendResponse({ ok: true });
      return;
    }
  });
})();
