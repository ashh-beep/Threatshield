// gatekeeper-cloudrun/extension/background.js

const WEBAPP_BASE = "https://gatekeeper-bd2zwcqxeq-el.a.run.app";
const PREDICT_API = `${WEBAPP_BASE}/api/predict`;

function shouldIgnoreUrl(url) {
  if (!url) return true;
  return (
    url.startsWith("chrome://") ||
    url.startsWith("about:") ||
    url.startsWith("edge://") ||
    url.startsWith("file://") ||
    url.startsWith("chrome-extension://")
  );
}

function isHttpUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

async function predictUrl(url) {
  const res = await fetch(PREDICT_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Predict API failed ${res.status}: ${text}`);
  }

  return await res.json();
}

async function ensureContentScript(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, { type: "GATEKEEPER_PING" }, (resp) => {
      if (chrome.runtime.lastError) return resolve(false);
      resolve(resp?.ok === true);
    });
  });
}

async function sendToast(tabId, url, out) {
  const reportUrl = `${WEBAPP_BASE}/?url=${encodeURIComponent(url)}`;

  const msg = {
    type: "GATEKEEPER_SHOW_TOAST",
    payload: {
      url,
      verdict: out?.verdict ?? "Risk check",
      score: out?.risk_score ?? null,
      color: out?.risk_color ?? "green",
      reportUrl
    }
  };

  const ok = await ensureContentScript(tabId);
  if (!ok) return false;

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, msg, () => {
      resolve(!chrome.runtime.lastError);
    });
  });
}

async function handleUrl(tabId, url) {
  try {
    if (!tabId || !isHttpUrl(url) || shouldIgnoreUrl(url)) return;

    const key = `last:${tabId}`;
    const prev = (await chrome.storage.session.get(key))[key];
    if (prev && prev.url === url && Date.now() - prev.t < 2000) return;
    await chrome.storage.session.set({ [key]: { url, t: Date.now() } });

    const out = await predictUrl(url);
    if (out) await sendToast(tabId, url, out);
  } catch (e) {
    console.error("Gatekeeper error:", e);
  }
}

chrome.webNavigation.onCommitted.addListener((d) => {
  if (d.frameId !== 0) return;
  handleUrl(d.tabId, d.url);
});

chrome.webNavigation.onHistoryStateUpdated.addListener((d) => {
  if (d.frameId !== 0) return;
  handleUrl(d.tabId, d.url);
});

chrome.webNavigation.onReferenceFragmentUpdated.addListener((d) => {
  if (d.frameId !== 0) return;
  handleUrl(d.tabId, d.url);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab?.url) return;
  handleUrl(tabId, tab.url);
});
