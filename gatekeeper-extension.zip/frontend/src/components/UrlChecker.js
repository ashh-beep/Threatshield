import React, { useEffect, useState } from "react";
import ResultCard from "./ResultCard";
import SecurityTips from "./SecurityTips";

export default function UrlChecker() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState(null);
  const [reasons, setReasons] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const checkUrl = async (overrideUrl) => {
    const u = (overrideUrl ?? url).trim();
    if (!u) return;

    setLoading(true);
    setResult(null);
    setReasons([]);
    setError("");

    try {
      // CHANGED: use same-origin API for Docker/Cloud Run
      const res = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: u })
      });

      if (!res.ok) {
        const txt = await res.text();
        throw new Error(`API ${res.status}: ${txt}`);
      }

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setResult({
        score: data.risk_score,
        color: data.risk_color,
        verdict: data.verdict,
        rawPrediction: data.prediction,
        probPhish: data.phishing_probability
      });

      setReasons(data.reasons || []);
    } catch (e) {
      setError(e.message || "Failed to fetch");
    } finally {
      setLoading(false);
    }
  };

  // ADDED: auto-fill if opened with /?url=...
  useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    const u = qs.get("url");
    if (u) {
      setUrl(u);
      setTimeout(() => checkUrl(u), 0);
    }
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "4rem" }}>
      {/* Search row */}
      <div style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center", width: "100%", marginTop: "8px" }}>
        <input
          placeholder="Paste your link here.."
          value={url}
          spellCheck={false}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !loading && checkUrl()}
          style={{
            width: "65%",
            maxWidth: "900px",
            paddingLeft: "56px",
            paddingRight: "56px",
            paddingTop: "10px",
            paddingBottom: "10px",
            fontSize: "1.05rem",
            background: "#ffffff",
            color: "#000000",
            borderRadius: "10px",
            border: "1px solid #ffffff",
            outline: "none",
            boxSizing: "border-box"
          }}
        />

        <div style={{ width: "12px" }} />

        <button
          onClick={() => checkUrl()}
          disabled={loading || !url}
          style={{
            paddingTop: "12px",
            paddingBottom: "12px",
            paddingLeft: "30px",
            paddingRight: "30px",
            borderRadius: "10px",
            border: "none",
            fontSize: "1rem",
            fontWeight: 600,
            cursor: loading || !url ? "default" : "pointer",
            background: "linear-gradient(90deg, #22e9be, #10b981)",
            color: "#062521",
            boxShadow: "0 4px 18px rgba(0,0,0,0.4)",
            opacity: loading || !url ? 0.6 : 1,
            whiteSpace: "nowrap"
          }}
        >
          {loading ? "Checking..." : "Check"}
        </button>
      </div>

      {/* Error */}
      {error && (
        <div style={{ color: "#f97373", fontSize: "12px", marginTop: "8px" }}>
          {error}
        </div>
      )}

      {/* Result */}
      {result && (
        <div style={{ marginTop: "20px" }}>
          <ResultCard result={result} reasons={reasons} url={url} />
        </div>
      )}

      {/* Tips */}
      <div style={{ marginTop: result ? "24px" : "32px" }}>
        <SecurityTips />
      </div>
    </div>
  );
}
