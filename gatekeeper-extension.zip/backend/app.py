import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import joblib
import numpy as np

from backend.features_from_url import extract_features_from_url

BASE_DIR = os.path.dirname(os.path.abspath(__file__))        # /app/backend
APP_DIR = os.path.dirname(BASE_DIR)                          # /app
FRONTEND_BUILD_DIR = os.path.join(APP_DIR, "frontend_build") # /app/frontend_build

app = Flask(__name__, static_folder=FRONTEND_BUILD_DIR, static_url_path="")
CORS(app)

MODEL_PATH = os.path.join(BASE_DIR, "phishing_rf_model.pkl")
model = joblib.load(MODEL_PATH)


def score_risk(prediction, proba_safe, proba_phish):
    p = float(proba_phish)

    if p <= 0.2:
        score_10 = 1 + int(round((p / 0.2) * 2))
    elif p <= 0.5:
        score_10 = 4 + int(round(((p - 0.2) / 0.3) * 2))
    else:
        score_10 = 7 + int(round(((p - 0.5) / 0.5) * 3))

    score_10 = max(1, min(10, score_10))
    verdict = "High Risk" if prediction == 1 else "Safe"
    color = "red" if prediction == 1 else "green"
    return score_10, color, verdict, p


@app.get("/api/health")
def api_health():
    return jsonify({"status": "ok"})


@app.post("/api/predict")
def api_predict():
    try:
        data = request.get_json(silent=True) or {}
        url = (data.get("url") or "").strip()
        if not url:
            return jsonify({"error": "URL is required"}), 400

        features = extract_features_from_url(url)
        features_arr = np.array(features).reshape(1, -1)

        probas = model.predict_proba(features_arr)[0]
        classes = model.classes_

        if (-1 not in classes) or (1 not in classes):
            return jsonify({"error": "Model classes must contain -1 and 1"}), 500

        idx_safe = int(np.where(classes == -1)[0][0])
        idx_phish = int(np.where(classes == 1)[0][0])

        proba_safe = float(probas[idx_safe])
        proba_phish = float(probas[idx_phish])
        pred = int(model.predict(features_arr)[0])  # -1 safe, 1 phishing

        risk_score, risk_color, verdict, p_phish = score_risk(pred, proba_safe, proba_phish)

        return jsonify({
            "url": url,
            "prediction": pred,
            "risk_score": risk_score,
            "risk_color": risk_color,
            "verdict": verdict,
            "phishing_probability": p_phish,
            "reasons": [url]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Serve React (SPA) at /
@app.get("/")
def serve_index():
    return send_from_directory(FRONTEND_BUILD_DIR, "index.html")


# Catch-all: if file exists serve it, else serve index.html (SPA routing)
@app.get("/<path:path>")
def serve_static_or_index(path):
    full_path = os.path.join(FRONTEND_BUILD_DIR, path)
    if os.path.exists(full_path):
        return send_from_directory(FRONTEND_BUILD_DIR, path)
    return send_from_directory(FRONTEND_BUILD_DIR, "index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
