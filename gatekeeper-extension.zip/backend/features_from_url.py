# webapp/features_from_url.py

import re
from urllib.parse import urlparse

def has_ip_address(url: str) -> int:
    try:
        host = urlparse(url).netloc
    except Exception:
        host = url
    ip_regex = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")
    return 1 if ip_regex.match(host) else -1

def url_length_feature(url: str) -> int:
    length = len(url)
    # Typical thresholds from phishing literature; adjust if needed
    if length < 54:
        return -1          # legitimate
    elif length <= 75:
        return 0           # suspicious
    else:
        return 1           # phishing

def shortening_service(url: str) -> int:
    shorteners = [
        "bit.ly", "goo.gl", "tinyurl.com", "t.co", "ow.ly",
        "is.gd", "buff.ly", "adf.ly", "bit.do"
    ]
    host = urlparse(url).netloc.lower()
    return 1 if any(s in host for s in shorteners) else -1

def having_at_symbol(url: str) -> int:
    return 1 if "@" in url else -1

def double_slash_redirecting(url: str) -> int:
    first = url.find("//")
    return 1 if url.find("//", first + 2) != -1 else -1

def prefix_suffix(url: str) -> int:
    host = urlparse(url).netloc
    return 1 if "-" in host else -1

def sub_domain(url: str) -> int:
    host = urlparse(url).hostname or ""
    parts = host.split(".")
    if len(parts) <= 2:
        return -1
    elif len(parts) == 3:
        return 0
    else:
        return 1

def ssl_final_state(url: str) -> int:
    # Approximation: HTTPS => legitimate
    return -1 if url.lower().startswith("https://") else 1

def domain_registration_length() -> int:
    # No WHOIS lookup in this mini-project; treat as legitimate
    return -1

def favicon_feature() -> int:
    # No page parsing; neutral
    return 0

def port_feature(url: str) -> int:
    parsed = urlparse(url)
    if parsed.port is None:
        return -1
    return 1 if parsed.port not in (80, 443) else -1

def https_token(url: str) -> int:
    host = urlparse(url).netloc.lower()
    # If "https" appears in domain label itself, suspicious
    clean = host.replace("https://", "")
    return 1 if "https" in clean else -1

def neutral_zero() -> int:
    return 0

def neutral_minus1() -> int:
    return -1

def submitting_to_email(url: str) -> int:
    return 1 if "mailto:" in url else -1

def abnormal_url(url: str) -> int:
    parsed = urlparse(url)
    host = parsed.netloc
    return -1 if host and host in url else 1

def extract_features_from_url(url: str):
    """
    Returns a list of 30 features in the SAME order as phishing.csv
    (excluding 'Index' and 'class').
    """

    return [
        # 1  Having_IP_Address
        has_ip_address(url),

        # 2  URL_Length
        url_length_feature(url),

        # 3  Shortining_Service
        shortening_service(url),

        # 4  Having_At_Symbol
        having_at_symbol(url),

        # 5  Double_slash_redirecting
        double_slash_redirecting(url),

        # 6  Prefix_Suffix
        prefix_suffix(url),

        # 7  Sub_Domain
        sub_domain(url),

        # 8  SSLfinal_State
        ssl_final_state(url),

        # 9  Domain_registeration_length
        domain_registration_length(),

        # 10 Favicon
        favicon_feature(),

        # 11 Port
        port_feature(url),

        # 12 HTTPS_token
        https_token(url),

        # 13 Request_URL
        neutral_zero(),

        # 14 URL_of_Anchor
        neutral_zero(),

        # 15 Links_in_tags
        neutral_zero(),

        # 16 SFH
        neutral_zero(),

        # 17 Submitting_to_email
        submitting_to_email(url),

        # 18 Abnormal_URL
        abnormal_url(url),

        # 19 Redirect
        neutral_zero(),

        # 20 on_mouseover
        neutral_zero(),

        # 21 RightClick
        neutral_zero(),

        # 22 popUpWidnow
        neutral_zero(),

        # 23 Iframe
        neutral_zero(),

        # 24 age_of_domain
        neutral_minus1(),

        # 25 DNSRecord
        neutral_minus1(),

        # 26 web_traffic
        neutral_minus1(),

        # 27 Page_Rank
        neutral_minus1(),

        # 28 Google_Index
        neutral_minus1(),

        # 29 Links_pointing_to_page
        neutral_zero(),

        # 30 Statistical_report
        neutral_zero(),
    ]
